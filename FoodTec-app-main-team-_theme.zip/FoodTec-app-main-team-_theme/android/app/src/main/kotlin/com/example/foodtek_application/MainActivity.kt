package com.example.foodtek_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
