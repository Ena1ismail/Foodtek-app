import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:foodtek/controller/login_controller.dart';
import 'package:foodtek/l10n/app_localizations.dart';
import 'package:foodtek/view/screens/registration_screens/login_screen.dart';
import 'package:foodtek/view/widgets/onboarding_widgets/back_arrow_widget.dart';
import 'package:foodtek/view/widgets/registration_widgets/login_button_widget.dart';
import 'package:foodtek/view/widgets/registration_widgets/password_field_widget.dart';
import 'package:provider/provider.dart';
import '../../../controller/lang_controller.dart';
import '../../widgets/onboarding_widgets/app_title_widget.dart';

class SuccessResetPasswordScreen extends StatefulWidget {
  const SuccessResetPasswordScreen({super.key});

  @override
  State<SuccessResetPasswordScreen> createState() =>
      _SuccessResetPasswordScreenState();
}

class _SuccessResetPasswordScreenState
    extends State<SuccessResetPasswordScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 4), () {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
            (route) => false,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    LangController langController =
    Provider.of<LangController>(context, listen: false);
    LoginController loginController = Provider.of<LoginController>(
      context,
      listen: false,
    );

    return Scaffold(
      backgroundColor: theme.colorScheme.primary,
      body: Stack(
        children: [
          Center(
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/pattern.png'),
                  fit: BoxFit.fill,
                ),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 30.h),
                    AppTitleWidget(),
                    SizedBox(height: 25.h),
                  ],
                ),
              ),
            ),
          ),
          Center(
            child: Container(
              height: 437.h,
              width: 343.w,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                color: theme.colorScheme.surface, // لون السطح الديناميكي
              ),
              child: Padding(
                padding: EdgeInsets.only(left: 24.sp),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      BackArrowWidget(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                      SizedBox(height: 24.h),
                      Text(
                        AppLocalizations.of(context)!.reset_password_title,
                        textAlign: TextAlign.center,
                        style: theme.textTheme.headlineLarge?.copyWith(
                          color: theme.colorScheme.onSurface, // لون النص الديناميكي
                        ),
                      ),
                      SizedBox(height: 12.h),
                      Text.rich(
                        TextSpan(
                          text: AppLocalizations.of(context)!.current_password,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant, // لون النص الفرعي الديناميكي
                          ),
                          children: [
                            TextSpan(
                              text: AppLocalizations.of(context)!.login_title,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: theme.colorScheme.primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 24.h),
                      PasswordFieldWidget(
                        loginController: loginController,
                        title: AppLocalizations.of(context)!.new_password,
                        controller: loginController.passwordController,
                        hintText: AppLocalizations.of(context)!.new_password_hint,
                        obscureText: false,
                      ),
                      SizedBox(height: 16.h),
                      PasswordFieldWidget(
                        loginController: loginController,
                        title: AppLocalizations.of(context)!.confirm_password,
                        controller: loginController.confirmPasswordController,
                        hintText: AppLocalizations.of(context)!.confirm_password_hint,
                        obscureText: false,
                      ),
                      SizedBox(height: 24.h),
                      LoginButtonWidget(
                        textColor: theme.colorScheme.onPrimary,
                        buttonName: AppLocalizations.of(context)!.register_button,
                        onPressed: () {},
                      ),
                      SizedBox(height: 24.h),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Center(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
              child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  color: theme.colorScheme.background.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  "assets/images/s.png",
                  height: 287.h,
                  width: 430.5.w,
                ),
                Text(
                  AppLocalizations.of(context)!.congratulations,
                  style: theme.textTheme.headlineLarge?.copyWith(
                    color: theme.colorScheme.onBackground, // لون النص الديناميكي
                  ),
                ),
                Text(
                  AppLocalizations.of(context)!.password_reset_success,
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: theme.colorScheme.onBackground, // لون النص الديناميكي
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}